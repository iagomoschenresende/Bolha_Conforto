from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5ebcf0b558c9'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # Adicionando a coluna 'user_id' como nullable
    with op.batch_alter_table('todo', schema=None) as batch_op:
        batch_op.add_column(sa.Column('user_id', sa.Integer(), nullable=True))  # Coluna nullable
        batch_op.create_foreign_key(
            'fk_todo_user',  # Nome da constraint
            'user',           # Tabela referenciada
            ['user_id'],      # Coluna da tabela 'todo' que será a chave estrangeira
            ['id']            # Coluna da tabela 'user' que será a chave primária
        )

def downgrade():
    # Removendo a chave estrangeira e a coluna 'user_id'
    with op.batch_alter_table('todo', schema=None) as batch_op:
        batch_op.drop_constraint('fk_todo_user', type_='foreignkey')  # Nome da constraint
        batch_op.drop_column('user_id')
