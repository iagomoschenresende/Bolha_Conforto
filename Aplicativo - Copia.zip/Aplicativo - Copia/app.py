from datetime import datetime, timezone
from flask import Flask, render_template, url_for, request, redirect, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin, LoginManager, login_user, login_required, logout_user, current_user
from flask_migrate import Migrate
from sqlalchemy.exc import IntegrityError


app = Flask(__name__)
app.config['SECRET_KEY'] = 'carro123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todos.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    descricao = db.Column(db.Text, nullable=True)
    todos = db.relationship('Todo', backref='owner', lazy=True)
    contatos = db.relationship('ContatoProfissional', backref='usuario', lazy=True)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(200), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.now(timezone.utc))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    concluida = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return '<Task %r>' % self.id

class ContatoProfissional(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    telefone = db.Column(db.String(20), nullable=False)
    especializacao = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)



@app.route('/', methods=['POST', 'GET'])
@login_required
def index():
    if request.method == 'POST':
        task_content = request.form['content']
        new_task = Todo(content=task_content, owner=current_user)

        try:
            db.session.add(new_task)
            db.session.commit()
            return redirect('/')
        except:
            return 'Erro na adição da task'
        
    else:
        tasks = Todo.query.filter_by(owner=current_user).order_by(Todo.date_created).all()
        return render_template('index.html', tasks=tasks)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect('/')
        flash('Login inválido. Tente novamente.')  
        return redirect('/login')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        hashed_password = generate_password_hash(request.form['password'], method='pbkdf2:sha256')
        new_user = User(username=request.form['username'], password=hashed_password)
        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect('/login')
        except IntegrityError:
            db.session.rollback()
            flash('Este nome de usuário já está em uso. Escolha outro.')
            return redirect('/login')
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

@app.route('/delete/<int:id>')
@login_required
def delete(id):
    task_to_delete = Todo.query.get_or_404(id)
    if task_to_delete.owner != current_user:
        return 'Você não tem permissão para excluir esta tarefa.'
    try:
        db.session.delete(task_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'Deu erro para deletar a task'

@app.route('/update/<int:id>', methods=['GET', 'POST'])
@login_required
def update(id):
    task = Todo.query.get_or_404(id)
    if task.owner != current_user:
        return 'Você não tem permissão para editar esta tarefa.'
    
    if request.method == 'POST':
        task.content = request.form['content']
        try:
            db.session.commit()
            return redirect('/')
        except:
            return 'Teve um erro na atualização da task'
    else:
        return render_template('update.html', task=task)

@app.route('/contato')
@login_required
def contato():
    # Lista fixa de profissionais (poderia vir do banco no futuro)
    profissionais = [
        {'nome': 'Dr. João Silva', 'telefone': '(27) 99999-0001', 'especializacao': 'Cardiologista'},
        {'nome': 'Dra. Ana Beatriz', 'telefone': '(27) 98888-1112', 'especializacao': 'Dermatologista'},
        {'nome': 'Dr. Lucas Mendes', 'telefone': '(27) 97777-2223', 'especializacao': 'Ortopedista'}
    ]
    return render_template('contato.html', profissionais=profissionais)


@app.route('/salvar_profissional', methods=['POST'])
@login_required
def salvar_profissional():
    nome = request.form['nome']
    telefone = request.form['telefone']
    especializacao = request.form['especializacao']
    novo_contato = ContatoProfissional(nome=nome, telefone=telefone, especializacao=especializacao, usuario=current_user)
    db.session.add(novo_contato)
    db.session.commit()
    return redirect('/contato')

@app.route('/perfil')
@login_required
def perfil():
    contatos_salvos = ContatoProfissional.query.filter_by(usuario=current_user).all()
    return render_template('perfil.html', contatos=contatos_salvos)

@app.route('/remover_contato/<int:id>', methods=['POST'])
@login_required
def remover_contato(id):
    contato = ContatoProfissional.query.get_or_404(id)

    if contato.user_id != current_user.id:
        
        return redirect('/perfil')

    db.session.delete(contato)
    db.session.commit()
    
    return redirect('/perfil')

@app.route('/atualizar_descricao', methods=['POST'])
@login_required
def atualizar_descricao():
    nova_descricao = request.form.get('descricao')
    current_user.descricao = nova_descricao
    db.session.commit()
    
    return redirect(url_for('perfil'))

@app.route('/concluir/<int:id>', methods=['POST'])
@login_required
def concluir(id):
    task = Todo.query.get_or_404(id)
    if task.owner != current_user:
        return 'Sem permissão'
    task.concluida = not task.concluida
    db.session.commit()
    return redirect('/')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()

    app.run(debug=True)
